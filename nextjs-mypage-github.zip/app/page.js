
import ProfileCard from "../components/ProfileCard";
import StatCard from "../components/StatCard";
import MenuGrid from "../components/MenuGrid";
import PostGrid from "../components/PostGrid";

export default function Page() {
  return (
    <main style={{maxWidth:"900px",margin:"40px auto"}}>

      <h2>마이페이지</h2>

      <ProfileCard />

      <div style={{display:"flex",gap:"10px",marginTop:"20px"}}>
        <StatCard title="게시물" value="89"/>
        <StatCard title="팔로워" value="1248"/>
        <StatCard title="팔로잉" value="132"/>
      </div>

      <MenuGrid />

      <PostGrid />

    </main>
  );
}
