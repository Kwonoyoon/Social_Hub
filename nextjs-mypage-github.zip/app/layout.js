
export const metadata = {
  title: "마이페이지",
  description: "취향 기반 소셜허브"
};

export default function RootLayout({ children }) {
  return (
    <html lang="ko">
      <body style={{background:"#f5f6fa",fontFamily:"sans-serif"}}>
        {children}
      </body>
    </html>
  );
}
