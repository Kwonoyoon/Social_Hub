
export default function ProfileCard(){
  return(
    <div style={{
      background:"white",
      padding:"20px",
      borderRadius:"12px",
      display:"flex",
      justifyContent:"space-between",
      alignItems:"center",
      marginTop:"20px"
    }}>

      <div>
        <h3>응둥구</h3>
        <p>취향을 기록하는 공간 ✨</p>
      </div>

      <button style={{
        background:"#7c4dff",
        color:"white",
        border:"none",
        padding:"8px 14px",
        borderRadius:"8px"
      }}>
        프로필 수정
      </button>

    </div>
  )
}
