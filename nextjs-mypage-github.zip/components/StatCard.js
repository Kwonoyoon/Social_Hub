
export default function StatCard({title,value}){
  return(
    <div style={{
      flex:1,
      background:"white",
      padding:"20px",
      borderRadius:"12px",
      textAlign:"center"
    }}>

      <h3>{value}</h3>
      <p>{title}</p>

    </div>
  )
}
