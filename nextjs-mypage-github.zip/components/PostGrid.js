
export default function PostGrid(){

const posts=[1,2,3,4,5,6]

return(

<div style={{
background:"white",
padding:"20px",
borderRadius:"12px",
marginTop:"20px"
}}>

<h3>내 게시물</h3>

<div style={{
display:"grid",
gridTemplateColumns:"repeat(3,1fr)",
gap:"10px",
marginTop:"10px"
}}>

{posts.map((p)=>(

<div key={p} style={{
height:"120px",
background:"#dfe4ea",
borderRadius:"8px",
display:"flex",
alignItems:"center",
justifyContent:"center"
}}>

Post {p}

</div>

))}

</div>

</div>

)
}
