
export default function MenuGrid(){

  const menus=[
    "음악","영화","책","게임","카페","여행","사진","패션"
  ]

  return(

    <div style={{
      background:"white",
      padding:"20px",
      borderRadius:"12px",
      marginTop:"20px"
    }}>

      <h3>내 취향</h3>

      <div style={{
        display:"grid",
        gridTemplateColumns:"repeat(4,1fr)",
        gap:"10px",
        marginTop:"10px"
      }}>

      {menus.map((m)=>(

        <div key={m} style={{
          background:"#f1f2f6",
          padding:"15px",
          borderRadius:"8px",
          textAlign:"center"
        }}>
        {m}
        </div>

      ))}

      </div>

    </div>
  )
}
